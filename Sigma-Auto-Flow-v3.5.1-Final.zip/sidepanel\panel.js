/**
 * Sigma Auto Flow - Ultra-Fast Image Automation (v3.5.0 Image Pro)
 * Focused 100% on Rock-Solid Image Generation, Local Watermark Peeling & Auto-Downloads
 * By Hussien Morad & Antigravity ♥
 */

document.addEventListener("DOMContentLoaded", () => {
  // DOM Elements
  const promptInput = document.getElementById("promptInput");
  const detectedBadge = document.getElementById("detectedBadge");
  const importFileBtn = document.getElementById("importFileBtn");
  const fileInput = document.getElementById("fileInput");
  const addQueueBtn = document.getElementById("addQueueBtn");
  const testConnectionBtn = document.getElementById("testConnectionBtn");
  const testFeedback = document.getElementById("testFeedback");
  const connectionStatus = document.getElementById("connectionStatus");

  // Quick Guide Elements
  const guideToggle = document.getElementById("guideToggle");
  const guideBody = document.getElementById("guideBody");
  const guideArrow = document.getElementById("guideArrow");

  // Global Style
  const enableGlobalStyle = document.getElementById("enableGlobalStyle");
  const globalStylePrompt = document.getElementById("globalStylePrompt");
  const styleStatusBadge = document.getElementById("styleStatusBadge");

  // Settings
  const generationEngine = document.getElementById("generationEngine");
  const aspectRatio = document.getElementById("aspectRatio");
  const delaySeconds = document.getElementById("delaySeconds");
  const enableAudioChime = document.getElementById("enableAudioChime");
  const enableWatermarkPeeler = document.getElementById("enableWatermarkPeeler");

  // Media Modal Elements
  const mediaModal = document.getElementById("mediaModal");
  const mediaModalBackdrop = document.getElementById("mediaModalBackdrop");
  const mediaModalClose = document.getElementById("mediaModalClose");
  const mediaModalTitle = document.getElementById("mediaModalTitle");
  const mediaModalContainer = document.getElementById("mediaModalContainer");
  const mediaModalPrompt = document.getElementById("mediaModalPrompt");
  const mediaModalShowFolder = document.getElementById("mediaModalShowFolder");
  let currentModalDownloadId = null;

  // Progress Tracker
  const progressTracker = document.getElementById("progressTracker");
  const progressBarFill = document.getElementById("progressBarFill");
  const progressText = document.getElementById("progressText");
  const progressPercent = document.getElementById("progressPercent");

  // Controls
  const startBtn = document.getElementById("startBtn");
  const pauseBtn = document.getElementById("pauseBtn");
  const resumeBtn = document.getElementById("resumeBtn");
  const stopBtn = document.getElementById("stopBtn");

  // Queue
  const queueContainer = document.getElementById("queueContainer");
  const exportQueueBtn = document.getElementById("exportQueueBtn");
  const clearQueueBtn = document.getElementById("clearQueueBtn");
  const statTotal = document.getElementById("statTotal");
  const statPending = document.getElementById("statPending");
  const statRunning = document.getElementById("statRunning");
  const statDone = document.getElementById("statDone");
  const statFailed = document.getElementById("statFailed");

  // Terminal Log
  const activityLog = document.getElementById("activityLog");
  const exportReportBtn = document.getElementById("exportReportBtn");
  const clearLogBtn = document.getElementById("clearLogBtn");

  // State
  let queue = [];
  let runnerState = "IDLE"; // IDLE, RUNNING, PAUSED, STOPPED
  let isLoopRunning = false;

  // Web Audio Context for Chimes
  let audioCtx = null;
  function playChime(type = "scene") {
    if (!enableAudioChime || !enableAudioChime.checked) return;
    try {
      if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === "suspended") audioCtx.resume();

      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);

      const now = audioCtx.currentTime;
      if (type === "complete") {
        osc.frequency.setValueAtTime(587.33, now); // D5
        osc.frequency.setValueAtTime(880, now + 0.12); // A5
        gain.gain.setValueAtTime(0.18, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
        osc.start(now);
        osc.stop(now + 0.5);
      } else {
        osc.frequency.setValueAtTime(659.25, now); // E5
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
        osc.start(now);
        osc.stop(now + 0.25);
      }
    } catch {}
  }

  // Activity Log Writer
  function appendLog(text) {
    const time = new Date().toLocaleTimeString("ar-EG", { hour12: false });
    const line = document.createElement("div");
    line.className = "log-line";
    line.textContent = `[${time}] ${text}`;
    activityLog.appendChild(line);
    activityLog.scrollTop = activityLog.scrollHeight;
  }

  // Clear Terminal Log
  if (clearLogBtn) {
    clearLogBtn.addEventListener("click", () => {
      activityLog.innerHTML = "";
      appendLog("تم مسح السجل.");
    });
  }

  // Global Style Toggle
  enableGlobalStyle.addEventListener("change", () => {
    const isChecked = enableGlobalStyle.checked;
    styleStatusBadge.textContent = isChecked ? "مُفعّل لجميع المشاهد" : "مُعطّل";
    styleStatusBadge.className = isChecked ? "badge active-badge" : "badge";
    savePersistedState();
  });

  globalStylePrompt.addEventListener("input", () => {
    savePersistedState();
  });

  // Media Lightbox Modal Handlers
  function openMediaModal(url, title, promptText, downloadId) {
    if (!mediaModal) return;
    currentModalDownloadId = downloadId || null;
    if (mediaModalTitle) mediaModalTitle.textContent = title || "معاينة الصورة";
    if (mediaModalPrompt) mediaModalPrompt.textContent = promptText || "";
    if (mediaModalContainer) {
      mediaModalContainer.innerHTML = "";
      const img = document.createElement("img");
      img.src = url;
      img.alt = title || "Preview";
      img.style.maxWidth = "100%";
      img.style.maxHeight = "60vh";
      img.style.objectFit = "contain";
      mediaModalContainer.appendChild(img);
    }
    if (mediaModalShowFolder) {
      mediaModalShowFolder.style.display = currentModalDownloadId ? "inline-flex" : "none";
    }
    mediaModal.style.display = "flex";
  }

  function closeMediaModal() {
    if (!mediaModal) return;
    mediaModal.style.display = "none";
    if (mediaModalContainer) mediaModalContainer.innerHTML = "";
    currentModalDownloadId = null;
  }

  if (mediaModalClose) mediaModalClose.addEventListener("click", closeMediaModal);
  if (mediaModalBackdrop) mediaModalBackdrop.addEventListener("click", closeMediaModal);
  if (mediaModalShowFolder) {
    mediaModalShowFolder.addEventListener("click", () => {
      if (currentModalDownloadId) {
        chrome.runtime.sendMessage({ type: "SHOW_DOWNLOAD", downloadId: currentModalDownloadId });
      }
    });
  }
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && mediaModal && mediaModal.style.display !== "none") {
      closeMediaModal();
    }
  });

  [generationEngine, aspectRatio, delaySeconds, enableAudioChime, enableWatermarkPeeler].forEach(el => {
    if (el) {
      el.addEventListener("change", () => savePersistedState());
    }
  });

  // Test Connection
  testConnectionBtn.addEventListener("click", async () => {
    testFeedback.style.display = "block";
    testFeedback.className = "test-feedback";
    testFeedback.textContent = "جاري فحص الاتصال بالتبويب...";

    const tab = await getTargetTab();
    if (!tab) {
      testFeedback.className = "test-feedback error";
      testFeedback.textContent = "❌ لم يتم العثور على تبويب Google Flow / Labs. افتح الموقع وتأكد من تسجيل الدخول.";
      return;
    }

    try {
      await ensureTabInjected(tab.id);
      chrome.tabs.sendMessage(tab.id, { type: "TEST_CONNECTION" }, (res) => {
        if (chrome.runtime.lastError) {
          testFeedback.className = "test-feedback error";
          testFeedback.textContent = "❌ تعذر إرسال الأمر للتبويب. يرجى إعادة تحميل صفحة فلو (F5).";
        } else if (res && res.success) {
          testFeedback.className = "test-feedback success";
          testFeedback.textContent = res.message;
        } else {
          testFeedback.className = "test-feedback error";
          testFeedback.textContent = res ? res.message : "خطأ غير معروف في الاتصال.";
        }
      });
    } catch (e) {
      testFeedback.className = "test-feedback error";
      testFeedback.textContent = `❌ استثناء: ${e.message}`;
    }
  });

  // Target Tab Resolver
  async function getTargetTab() {
    const tabs = await chrome.tabs.query({ url: ["https://flow.google.com/*", "https://labs.google/*"] });
    if (!tabs || tabs.length === 0) return null;
    const active = tabs.find((t) => t.active);
    return active || tabs[0];
  }

  // Ensure scripts are loaded in tab
  async function ensureTabInjected(tabId) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "ENSURE_CONTENT_SCRIPT", tabId }, (res) => {
        resolve(res);
      });
    });
  }

  // Interactive Quick Guide Toggle
  if (guideToggle && guideBody && guideArrow) {
    guideToggle.addEventListener("click", () => {
      const isHidden = guideBody.style.display === "none";
      guideBody.style.display = isHidden ? "flex" : "none";
      guideArrow.classList.toggle("open", isHidden);
    });
  }

  // Live Auto Connection Status Checker
  async function updateConnectionStatus() {
    if (!connectionStatus) return;
    const tab = await getTargetTab();
    if (!tab) {
      connectionStatus.className = "connection-pill disconnected";
      connectionStatus.innerHTML = '<span class="dot"></span><span class="status-text">🔴 غير متصل</span>';
      connectionStatus.title = "لم يتم العثور على تبويب Google Flow مفتوح. افتح الموقع للاتصال.";
      return;
    }

    const isProject = tab.url && tab.url.includes("/project/");
    if (!isProject) {
      connectionStatus.className = "connection-pill warning";
      connectionStatus.innerHTML = '<span class="dot"></span><span class="status-text">🟡 افتح مشروعاً</span>';
      connectionStatus.title = "الموقع مفتوح، يرجى الدخول داخل مشروع لبدء توليد الصور.";
      return;
    }

    chrome.tabs.sendMessage(tab.id, { type: "PING" }, (res) => {
      if (chrome.runtime.lastError || !res) {
        connectionStatus.className = "connection-pill warning";
        connectionStatus.innerHTML = '<span class="dot"></span><span class="status-text">🟡 تحديث فلو (F5)</span>';
        connectionStatus.title = "اضغط F5 في صفحة فلو لتفعيل الاتصال.";
      } else {
        connectionStatus.className = "connection-pill connected";
        connectionStatus.innerHTML = '<span class="dot"></span><span class="status-text">🟢 متصل بالمشروع</span>';
        connectionStatus.title = "متصل بنجاح وجاهز لتوليد الصور فائق السرعة!";
      }
    });
  }

  updateConnectionStatus();
  setInterval(updateConnectionStatus, 2500);
  if (connectionStatus) {
    connectionStatus.addEventListener("click", () => {
      updateConnectionStatus();
      appendLog("🔄 جاري تحديث حالة الاتصال بتبويب فلو...");
    });
  }

  // Real-time Robust Prompt Parser
  function parsePromptInput(text) {
    if (!text || !text.trim()) return [];
    const raw = text.trim();

    // 1. JSON Array or Object Support
    if (raw.startsWith('[') || raw.startsWith('{')) {
      try {
        const data = JSON.parse(raw);
        const list = Array.isArray(data) ? data : data.scenes || [];
        if (list.length) {
          return list.map((item, idx) => ({
            id: item.id || `scene_${Date.now()}_${idx}_${Math.random().toString(36).substring(2, 7)}`,
            sceneNumber: item.sceneNumber || idx + 1,
            sceneTitle: item.sceneTitle || `Scene ${String(idx + 1).padStart(2, "0")}`,
            imagePrompt: (item.imagePrompt || item.prompt || (typeof item === 'string' ? item : '')).trim(),
            status: item.status || "pending",
            imageUrl: item.imageUrl || null,
            watermarkRemoved: !!item.watermarkRemoved,
            downloadId: item.downloadId || null,
            error: item.error || null
          })).filter((x) => x.imagePrompt);
        }
      } catch {}
    }

    const lines = raw.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    const headerRegex = /^(?:#+\s*)?(?:(?:مشهد|المشهد|Scene|Shot)\s*(\d+)?|(\d+))(?:\s*[:\-\.]\s*(.*))?$/i;

    const hasHeaders = lines.some((l) => headerRegex.test(l));

    // 2. If NO scene headers found: smart split by paragraphs or lines
    if (!hasHeaders) {
      const paragraphs = raw.split(/\r?\n\s*\r?\n/).map((p) => p.trim()).filter(Boolean);
      const sourceList = paragraphs.length > 1 ? paragraphs : lines;
      return sourceList.map((chunk, idx) => {
        const clean = chunk.replace(/\r?\n/g, " ").replace(/^(?:صورة|Image|Prompt)\s*[:\-\.]\s*/i, "").trim();
        return {
          id: `scene_${Date.now()}_${idx}_${Math.random().toString(36).substring(2, 7)}`,
          sceneNumber: idx + 1,
          sceneTitle: `Scene ${String(idx + 1).padStart(2, "0")}`,
          imagePrompt: clean,
          status: "pending",
          imageUrl: null,
          watermarkRemoved: false,
          error: null
        };
      }).filter((x) => x.imagePrompt);
    }

    // 3. Header-based parsing (handles same-line prompts, multi-line prompts, and filters motion lines)
    const results = [];
    let current = null;

    for (const line of lines) {
      const isMotion = /^(?:حركة|Motion|Camera|Action)\s*[:\-\.]/i.test(line);
      if (isMotion) continue;

      const match = line.match(headerRegex);
      if (match && (match[1] || match[2] || /^(?:مشهد|المشهد|Scene|Shot)/i.test(line))) {
        if (current && (current.promptLines.length || current.inlinePrompt)) {
          const fullPrompt = [current.inlinePrompt, ...current.promptLines].filter(Boolean).join(" ").trim();
          if (fullPrompt) {
            results.push({
              id: `scene_${Date.now()}_${current.sceneNumber}_${Math.random().toString(36).substring(2, 7)}`,
              sceneNumber: current.sceneNumber,
              sceneTitle: current.sceneTitle,
              imagePrompt: fullPrompt,
              status: "pending",
              imageUrl: null,
              watermarkRemoved: false,
              error: null
            });
          }
        }

        const num = parseInt(match[1] || match[2] || (results.length + 1), 10);
        const rest = (match[3] || "").replace(/^(?:صورة|Image|Prompt)\s*[:\-\.]\s*/i, "").trim();

        current = {
          sceneNumber: num,
          sceneTitle: `Scene ${String(num).padStart(2, "0")}`,
          inlinePrompt: rest,
          promptLines: []
        };
      } else {
        const cleanLine = line.replace(/^(?:صورة|Image|Prompt)\s*[:\-\.]\s*/i, "").trim();
        if (!cleanLine) continue;

        if (!current) {
          current = {
            sceneNumber: results.length + 1,
            sceneTitle: `Scene ${String(results.length + 1).padStart(2, "0")}`,
            inlinePrompt: "",
            promptLines: []
          };
        }
        current.promptLines.push(cleanLine);
      }
    }

    if (current && (current.promptLines.length || current.inlinePrompt)) {
      const fullPrompt = [current.inlinePrompt, ...current.promptLines].filter(Boolean).join(" ").trim();
      if (fullPrompt) {
        results.push({
          id: `scene_${Date.now()}_${current.sceneNumber}_${Math.random().toString(36).substring(2, 7)}`,
          sceneNumber: current.sceneNumber,
          sceneTitle: current.sceneTitle,
          imagePrompt: fullPrompt,
          status: "pending",
          imageUrl: null,
          watermarkRemoved: false,
          error: null
        });
      }
    }

    return results;
  }

  // Update badge on input
  promptInput.addEventListener("input", () => {
    const parsed = parsePromptInput(promptInput.value);
    detectedBadge.textContent = `${parsed.length} صورة مكتشفة`;
    detectedBadge.className = parsed.length > 0 ? "badge active-badge" : "badge";
  });

  // Import TXT or JSON File
  importFileBtn.addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target.result;
      if (file.name.endsWith(".json")) {
        try {
          const parsedJson = JSON.parse(content);
          const rawItems = Array.isArray(parsedJson) ? parsedJson : parsedJson.scenes || [];
          queue = rawItems.map((item, idx) => ({
            id: item.id || `scene_${Date.now()}_${idx}`,
            sceneNumber: item.sceneNumber || idx + 1,
            sceneTitle: item.sceneTitle || `Scene ${String(idx + 1).padStart(2, "0")}`,
            imagePrompt: item.imagePrompt || item.prompt || "",
            status: item.status || "pending",
            imageUrl: item.imageUrl || null,
            watermarkRemoved: !!item.watermarkRemoved,
            downloadId: item.downloadId || null,
            error: item.error || null
          }));
          savePersistedState();
          renderQueue();
          appendLog(`تم استيراد ${queue.length} صورة بنجاح من ملف JSON.`);
          return;
        } catch {
          appendLog("⚠️ فشل تحليل ملف JSON، جاري قراءته كنص عادي...");
        }
      }

      promptInput.value = content;
      promptInput.dispatchEvent(new Event("input"));
      appendLog(`تم استيراد ملف "${file.name}" بنجاح.`);
    };
    reader.readAsText(file);
    fileInput.value = "";
  });

  // Add to Queue
  addQueueBtn.addEventListener("click", () => {
    const parsed = parsePromptInput(promptInput.value);
    if (parsed.length === 0) {
      alert("يرجى لصق برومبتات صالحة في الحقل أولاً!");
      return;
    }

    const currentMax = queue.reduce((max, item) => Math.max(max, item.sceneNumber || 0), 0);
    parsed.forEach((p, idx) => {
      p.sceneNumber = currentMax + idx + 1;
      p.sceneTitle = `Scene ${String(p.sceneNumber).padStart(2, "0")}`;
      queue.push(p);
    });

    promptInput.value = "";
    promptInput.dispatchEvent(new Event("input"));
    savePersistedState();
    renderQueue();
    appendLog(`تمت إضافة ${parsed.length} صورة جديدة إلى الطابور.`);
  });

  // Clear Queue (Instant, reliable, safe double-click confirmation without blocked window.confirm)
  let clearConfirmTimer = null;
  clearQueueBtn.addEventListener("click", () => {
    if (runnerState === "RUNNING") {
      appendLog("⚠️ يرجى إيقاف التشغيل أولاً قبل مسح الطابور!");
      return;
    }
    if (queue.length === 0) {
      appendLog("ℹ️ الطابور فارغ بالفعل.");
      return;
    }

    if (!clearConfirmTimer) {
      clearQueueBtn.textContent = "⚠️ اضغط للتأكيد";
      clearQueueBtn.classList.add("btn-danger-confirm");
      clearConfirmTimer = setTimeout(() => {
        clearQueueBtn.textContent = "🗑️ مسح القائمة";
        clearQueueBtn.classList.remove("btn-danger-confirm");
        clearConfirmTimer = null;
      }, 3500);
      return;
    }

    clearTimeout(clearConfirmTimer);
    clearConfirmTimer = null;
    clearQueueBtn.textContent = "🗑️ مسح القائمة";
    clearQueueBtn.classList.remove("btn-danger-confirm");

    queue = [];
    chrome.storage.local.remove(["sigma_queue", "sigma_runner_state"]).catch(() => {});
    savePersistedState();
    renderQueue();
    updateProgressBar();
    appendLog("🗑️ تم مسح جميع الصور من الطابور بنجاح.");
  });

  // Export Queue as JSON
  exportQueueBtn.addEventListener("click", () => {
    if (queue.length === 0) {
      alert("الطابور فارغ!");
      return;
    }
    const blob = new Blob([JSON.stringify(queue, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `SigmaAutoFlow_Queue_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    appendLog("تم تصدير ملف الطابور بنجاح.");
  });

  // Control Buttons
  startBtn.addEventListener("click", () => {
    if (queue.length === 0) {
      alert("الطابور فارغ! أضف برومبتات أولاً.");
      return;
    }
    const hasPending = queue.some((i) => i.status === "pending" || i.status === "failed");
    if (!hasPending) {
      alert("جميع الصور مكتملة بالفعل! أضف صوراً جديدة أو أعد محاولة الفاشلة.");
      return;
    }
    runnerState = "RUNNING";
    updateControlButtons();
    appendLog("🚀 بدء تشغيل طابور توليد الصور...");
    runQueueLoop();
  });

  pauseBtn.addEventListener("click", () => {
    runnerState = "PAUSED";
    updateControlButtons();
    appendLog("⏸️ تم الإيقاف المؤقت لطابور الصور.");
  });

  resumeBtn.addEventListener("click", () => {
    runnerState = "RUNNING";
    updateControlButtons();
    appendLog("⏯️ استئناف توليد الصور...");
    runQueueLoop();
  });

  stopBtn.addEventListener("click", () => {
    runnerState = "STOPPED";
    updateControlButtons();
    appendLog("⏹️ تم إيقاف طابور الصور.");
  });

  function updateControlButtons() {
    startBtn.disabled = runnerState === "RUNNING";
    pauseBtn.disabled = runnerState !== "RUNNING";
    resumeBtn.style.display = runnerState === "PAUSED" ? "inline-flex" : "none";
    pauseBtn.style.display = runnerState === "PAUSED" ? "none" : "inline-flex";
    stopBtn.disabled = runnerState === "IDLE" || runnerState === "STOPPED";
  }

  // Progress Bar
  function updateProgressBar() {
    if (queue.length === 0) {
      progressTracker.style.display = "none";
      return;
    }
    progressTracker.style.display = "block";
    const doneCount = queue.filter((i) => i.status === "done").length;
    const total = queue.length;
    const percent = Math.round((doneCount / total) * 100);

    progressBarFill.style.width = `${percent}%`;
    progressText.textContent = `الصورة ${doneCount} من ${total}`;
    progressPercent.textContent = `${percent}%`;
  }

  // Tab Messenger
  function sendTabMessage(tabId, message) {
    return new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(tabId, message, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(response);
        }
      });
    });
  }

  /**
   * Main Queue Execution Loop (100% Focused on Pure Image Generation)
   */
  async function runQueueLoop() {
    if (isLoopRunning) return;
    isLoopRunning = true;

    try {
      while (runnerState === "RUNNING") {
        const taskIndex = queue.findIndex((i) => i.status === "pending" || i.status === "failed");
        if (taskIndex === -1) {
          runnerState = "IDLE";
          updateControlButtons();
          appendLog("🎉 تهانينا! اكتمل توليد وحفظ جميع الصور في الطابور بنجاح.");
          playChime("complete");
          break;
        }

        const task = queue[taskIndex];
        task.status = "generating";
        task.error = null;
        appendLog(`📸 [${task.sceneTitle}] بدء توليد الصورة...`);
        renderQueue();
        savePersistedState();

        const tab = await getTargetTab();
        if (!tab) {
          task.status = "failed";
          task.error = "لم يتم العثور على تبويب Google Flow مفتوح";
          runnerState = "STOPPED";
          updateControlButtons();
          renderQueue();
          savePersistedState();
          appendLog("❌ خطأ: لم يتم العثور على تبويب الموقع.");
          break;
        }

        await ensureTabInjected(tab.id);

        let finalPrompt = task.imagePrompt;
        if (enableGlobalStyle && enableGlobalStyle.checked && globalStylePrompt.value.trim()) {
          finalPrompt = `${globalStylePrompt.value.trim()}, ${finalPrompt}`;
        }

        const selectedRatio = (aspectRatio && aspectRatio.value) || "16:9";
        let ratioDescriptor = "";
        if (selectedRatio === "16:9") {
          ratioDescriptor = "16:9 aspect ratio, wide landscape orientation, widescreen full-bleed composition, 4k ultra-high resolution, sharp focus";
        } else if (selectedRatio === "9:16") {
          ratioDescriptor = "9:16 aspect ratio, vertical portrait orientation, tall format, 4k ultra-high resolution, sharp focus";
        } else if (selectedRatio === "1:1") {
          ratioDescriptor = "1:1 square aspect ratio, centered framing, high resolution";
        } else if (selectedRatio === "4:3") {
          ratioDescriptor = "4:3 aspect ratio, classic landscape, high resolution";
        } else if (selectedRatio === "3:4") {
          ratioDescriptor = "3:4 aspect ratio, classic portrait, high resolution";
        }

        if (ratioDescriptor && !finalPrompt.includes(selectedRatio)) {
          finalPrompt = `${finalPrompt}, ${ratioDescriptor}`;
        }

        const formattedNum = String(task.sceneNumber).padStart(3, "0");
        const engineChoice = generationEngine ? generationEngine.value : "api";
        appendLog(`[${task.sceneTitle}] 📐 الأبعاد: ${selectedRatio} | الجودة: أصلية فائقة (Master Resolution)`);

        try {
          const result = await sendTabMessage(tab.id, {
            type: "GENERATE_IMAGE",
            payload: {
              sceneNumber: formattedNum,
              imagePrompt: finalPrompt,
              aspectRatio: aspectRatio.value,
              removeWatermark: enableWatermarkPeeler ? enableWatermarkPeeler.checked : true,
              generationMode: engineChoice
            }
          });

          if (result && result.success && result.imageResult) {
            task.imageUrl = result.imageResult;
            task.mediaId = result.mediaId || null;
            task.workflowId = result.workflowId || null;
            task.watermarkRemoved = !!result.watermarkRemoved;
            task.status = "done";
            const imgFilename = `Scene_${formattedNum}_Image.png`;
            appendLog(`[${task.sceneTitle}] 📥 تم حفظ الصورة محلياً: ${imgFilename}`);

            chrome.runtime.sendMessage({
              type: "DOWNLOAD_MEDIA",
              payload: { url: result.imageResult, filename: imgFilename }
            }, (dlRes) => {
              if (dlRes && dlRes.downloadId) {
                task.downloadId = dlRes.downloadId;
                savePersistedState();
                renderQueue();
              } else if (dlRes && dlRes.error) {
                appendLog(`[${task.sceneTitle}] ⚠️ تعذر الحفظ التلقائي: ${dlRes.error}`);
              }
            });
            playChime("scene");
          } else {
            task.status = "failed";
            task.error = result?.error || "فشل توليد الصورة";
            appendLog(`[${task.sceneTitle}] ❌ فشل: ${task.error}`);
          }
        } catch (err) {
          task.status = "failed";
          task.error = err.message || "فشل الاتصال بالصفحة";
          appendLog(`[${task.sceneTitle}] ❌ استثناء: ${task.error}`);
        }

        renderQueue();
        savePersistedState();
        updateProgressBar();

        // Safe delay between images
        const hasMore = queue.some((item) => item.status === "pending");
        if (hasMore && runnerState === "RUNNING") {
          const delay = Math.max(2, parseInt(delaySeconds.value, 10) || 6);
          for (let s = delay; s > 0 && runnerState === "RUNNING"; s--) {
            appendLog(`⏳ فاصل أمان: سيتم توليد الصورة التالية خلال ${s} ثوانٍ...`);
            await sleep(1000);
          }
        }
      }
    } finally {
      isLoopRunning = false;
    }
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // Render Queue UI
  function renderQueue() {
    let pending = 0,
      running = 0,
      done = 0,
      failed = 0;

    if (queue.length === 0) {
      queueContainer.innerHTML = `
        <div class="empty-state">
          لا توجد صور في الطابور حالياً.<br>
          الصق برومبتات الصور في الحقل أعلاه واضغط على "تحليل وإضافة للطابور".
        </div>`;
    } else {
      queueContainer.innerHTML = "";
      queue.forEach((item) => {
        if (item.status === "pending") pending++;
        else if (item.status === "generating") running++;
        else if (item.status === "done") done++;
        else if (item.status === "failed") failed++;

        const card = document.createElement("div");
        card.className = `scene-item status-${item.status}`;

        const statusLabel = {
          pending: "⏳ في الانتظار",
          generating: "⚙️ جاري التوليد...",
          done: "✅ مكتملة ومحمّلة",
          failed: "❌ فشل"
        }[item.status];

        card.innerHTML = `
          <div class="scene-header">
            <span class="scene-title">${escapeHtml(item.sceneTitle)}</span>
            <div style="display: flex; gap: 6px; align-items: center;">
              <span class="sub-badge ${item.status === "generating" ? "running" : item.status}">
                ${statusLabel}
              </span>
            </div>
          </div>

          <div class="scene-prompt-block">
            <div class="prompt-row">
              <span class="prompt-icon">🖼️ البرومبت:</span>
              <span class="prompt-text">${escapeHtml(item.imagePrompt)}</span>
            </div>
          </div>

          <div class="scene-footer">
            <div class="scene-badges">
              ${
                item.watermarkRemoved
                  ? `<span class="sub-badge active-badge" title="تم إزالة علامة Gemini/Flow المائية">✨ بدون علامة</span>`
                  : ""
              }
            </div>

            <div class="links-group">
              ${item.imageUrl ? `<button class="btn btn-outline btn-preview-img" data-id="${item.id}" style="font-size: 11px; padding: 4px 8px; color: #38bdf8; border-color: rgba(56, 189, 248, 0.4);" title="معاينة الصورة المكبرة داخل الأداة">👁️ معاينة الصورة</button>` : ""}
              ${item.downloadId ? `
                <button class="btn btn-outline btn-show-folder" data-did="${item.downloadId}" style="font-size: 11px; padding: 4px 8px; color: #34d399; border-color: rgba(52, 211, 153, 0.4);" title="إظهار الصورة في مجلد التنزيلات على جهازك">
                  📁 في المجلد
                </button>
              ` : ""}
              ${item.status === "failed" ? `<button class="btn-retry" data-id="${item.id}">إعادة المحاولة</button>` : ""}
            </div>
          </div>
          ${item.imageUrl ? `
            <div class="scene-preview-row">
              <a href="javascript:void(0)" class="thumb-preview-link" data-id="${item.id}" title="اضغط لمعاينة وتكبير الصورة داخل الأداة">
                <img src="${escapeHtml(item.imageUrl)}" class="scene-preview-thumb" alt="Preview">
              </a>
              ${item.watermarkRemoved ? `<span class="peeled-tag">✨ بدون علامة مائية</span>` : ""}
            </div>
          ` : ""}
          ${item.error ? `<div style="color:var(--danger);font-size:11px;padding-top:4px;">⚠️ ${escapeHtml(item.error)}</div>` : ""}
        `;

        const previewImgBtn = card.querySelector(".btn-preview-img");
        if (previewImgBtn) {
          previewImgBtn.addEventListener("click", () => {
            openMediaModal(item.imageUrl, `${item.sceneTitle} - صورة المشهد`, item.imagePrompt, item.downloadId);
          });
        }

        const thumbLink = card.querySelector(".thumb-preview-link");
        if (thumbLink) {
          thumbLink.addEventListener("click", () => {
            openMediaModal(item.imageUrl, `${item.sceneTitle} - صورة المشهد`, item.imagePrompt, item.downloadId);
          });
        }

        const showFolderBtn = card.querySelector(".btn-show-folder");
        if (showFolderBtn) {
          showFolderBtn.addEventListener("click", () => {
            const did = Number(showFolderBtn.getAttribute("data-did"));
            if (did) {
              chrome.runtime.sendMessage({ type: "SHOW_DOWNLOAD", downloadId: did });
            }
          });
        }

        const retryBtn = card.querySelector(".btn-retry");
        if (retryBtn) {
          retryBtn.addEventListener("click", () => {
            item.status = "pending";
            item.error = null;
            savePersistedState();
            renderQueue();
          });
        }

        queueContainer.appendChild(card);
      });
    }

    statTotal.textContent = queue.length;
    statPending.textContent = pending;
    statRunning.textContent = running;
    statDone.textContent = done;
    statFailed.textContent = failed;
  }

  function escapeHtml(str) {
    if (!str) return "";
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  // Storage Persistence
  function savePersistedState() {
    const state = {
      queue: queue,
      enableGlobalStyle: enableGlobalStyle.checked,
      globalStylePrompt: globalStylePrompt.value,
      aspectRatio: aspectRatio.value,
      delaySeconds: delaySeconds.value,
      enableAudioChime: enableAudioChime.checked,
      generationEngine: generationEngine ? generationEngine.value : "api",
      enableWatermarkPeeler: enableWatermarkPeeler ? enableWatermarkPeeler.checked : true
    };
    chrome.storage.local.set({ sigmaAutoFlowState: state });
  }

  function loadPersistedState() {
    chrome.storage.local.get(["sigmaAutoFlowState"], (data) => {
      const state = data.sigmaAutoFlowState;
      if (state) {
        if (Array.isArray(state.queue)) {
          queue = state.queue.map((item, idx) => ({
            id: item.id || `scene_${Date.now()}_${idx}`,
            sceneNumber: item.sceneNumber || idx + 1,
            sceneTitle: item.sceneTitle || `Scene ${String(idx + 1).padStart(2, "0")}`,
            imagePrompt: item.imagePrompt || item.prompt || "",
            status: item.status || "pending",
            imageUrl: item.imageUrl || null,
            watermarkRemoved: !!item.watermarkRemoved,
            mediaId: item.mediaId || null,
            workflowId: item.workflowId || null,
            downloadId: item.downloadId || null,
            error: item.error || null
          }));
        }
        if (typeof state.enableGlobalStyle === "boolean") {
          enableGlobalStyle.checked = state.enableGlobalStyle;
          styleStatusBadge.textContent = state.enableGlobalStyle ? "مُفعّل لجميع المشاهد" : "مُعطّل";
          styleStatusBadge.className = state.enableGlobalStyle ? "badge active-badge" : "badge";
        }
        if (state.globalStylePrompt) globalStylePrompt.value = state.globalStylePrompt;
        if (state.aspectRatio) aspectRatio.value = state.aspectRatio;
        if (state.generationEngine && generationEngine) generationEngine.value = state.generationEngine;
        if (state.delaySeconds) delaySeconds.value = state.delaySeconds;
        if (typeof state.enableAudioChime === "boolean") enableAudioChime.checked = state.enableAudioChime;
        if (typeof state.enableWatermarkPeeler === "boolean" && enableWatermarkPeeler) {
          enableWatermarkPeeler.checked = state.enableWatermarkPeeler;
        }
        renderQueue();
      }
    });
  }

  // Export Full Report
  if (exportReportBtn) {
    exportReportBtn.addEventListener("click", () => {
      if (queue.length === 0) {
        alert("لا توجد صور لتصدير تقرير عنها!");
        return;
      }
      const report = {
        tool: "Sigma Auto Flow",
        version: "3.5.0 Image Pro",
        timestamp: new Date().toISOString(),
        totalScenes: queue.length,
        doneScenes: queue.filter((i) => i.status === "done").length,
        failedScenes: queue.filter((i) => i.status === "failed").length,
        scenes: queue
      };
      const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `SigmaAutoFlow_Images_Report_${Date.now()}.json`;
      a.click();
      URL.revokeObjectURL(url);
      appendLog("تم تصدير تقرير الصور بنجاح.");
    });
  }

  // Initial Load
  loadPersistedState();
  updateProgressBar();
  appendLog("تم تهيئة Sigma Auto Flow v3.5.0 Image Pro بنجاح.");
});
