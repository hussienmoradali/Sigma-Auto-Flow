/**
 * Sigma Auto Flow - Ultra-Fast Image Engine (v3.5.1 Final Pure Image Edition)
 * Authentic Google Flow BatchExecute RPC (rpcid: ogiZ0b) with Master Resolution (=s0) & Watermark Peeler
 * By Hussien Morad & Antigravity ♥
 */

(() => {
  if (window.__SIGMA_AUTO_FLOW_INJECTED__) {
    console.log("[SigmaAutoFlow] API Engine already active on page.");
    return;
  }
  window.__SIGMA_AUTO_FLOW_INJECTED__ = true;
  console.log("[SigmaAutoFlow v3.5.1 Final Image Edition] Initialized on:", location.href);

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function log(text) {
    console.log(`[SigmaAutoFlow] ${text}`);
    chrome.runtime.sendMessage({ type: "ACTIVITY_LOG", text }).catch(() => {});
  }

  /**
   * MainWorld Bridge Communication (Scrapes WIZ_global_data & mints authentic reCAPTCHA)
   */
  let nextBridgeId = 1;
  function callMainWorld(kind, payload = {}) {
    return new Promise((resolve, reject) => {
      const id = "af_" + Date.now() + "_" + nextBridgeId++;
      const timeout = setTimeout(() => {
        window.removeEventListener("message", onMessage);
        reject(new Error("MainWorld bridge request timed out: " + kind));
      }, 15000);

      function onMessage(ev) {
        if (ev.source !== window || ev.origin !== location.origin) return;
        const d = ev.data;
        if (!d || d.__af !== "AF_MW_RES" || d.id !== id) return;

        window.removeEventListener("message", onMessage);
        clearTimeout(timeout);
        if (d.error) {
          reject(new Error(d.error));
        } else {
          resolve(d.result);
        }
      }

      window.addEventListener("message", onMessage);
      window.postMessage({ __af: "AF_MW_REQ", id, kind, payload }, location.origin);
    });
  }

  /**
   * Extract current project ID from URL
   */
  function getProjectId() {
    const match = location.pathname.match(/\/project\/([\w-]+)/);
    return match ? match[1] : null;
  }

  /**
   * Extract auth index (/u/0/, /u/1/, etc.)
   */
  function getAuthIndex() {
    const match = location.pathname.match(/\/u\/(\d+)\//);
    return match ? match[1] : "0";
  }

  /**
   * Transforms any Google image URL into Original Master Resolution (=s0 / Full-HD / 4K)
   * Eliminates blurry 512px canvas thumbnails and enforces crystal-clear master quality!
   */
  function getHighResImageUrl(url) {
    if (!url || typeof url !== "string") return url;

    // 1. For googleusercontent.com URLs (lh3.googleusercontent.com/asb/...)
    if (url.includes("googleusercontent.com")) {
      // If it contains a size/scaling modifier like =s512, =w640-h360, =s400, =s1024, =w..., =h...
      if (/=(?:[swhd]\d+|(?:[sw]\d+-h\d+))[a-zA-Z0-9_-]*/i.test(url)) {
        return url.replace(/=(?:[swhd]\d+|(?:[sw]\d+-h\d+))[a-zA-Z0-9_-]*/i, "=s0");
      }
      // If it doesn't have an =s modifier and no query string, append =s0 for original full master resolution
      if (!url.includes("?") && !url.includes("=s")) {
        return url + "=s0";
      }
    }

    // 2. For flow-content.google URLs: remove downscaling query parameters cleanly using URLSearchParams
    if (url.includes("flow-content.google") && url.includes("?")) {
      try {
        const u = new URL(url);
        ["w", "h", "width", "height", "size", "s"].forEach((p) => u.searchParams.delete(p));
        return u.toString();
      } catch {}
    }

    return url;
  }

  /**
   * Safely navigate nested arrays / objects
   */
  function v(e, ...t) {
    let r = e;
    for (const n of t) {
      if (Array.isArray(r) && typeof n === "number") {
        const i = n < 0 ? r.length + n : n;
        if (i < 0 || i >= r.length) return;
        r = r[i];
      } else if (r && typeof r === "object" && !Array.isArray(r) && n in r) {
        r = r[n];
      } else return;
    }
    return r;
  }

  function x(e) {
    return typeof e === "string" ? e : e == null ? null : String(e);
  }

  /**
   * Parse image result from Google Flow's internal protobuf-json
   */
  function parseImageResult(e) {
    try {
      const t = v(e, 0, 0);
      if (t) {
        const url = x(v(t, 6, 0, 13));
        const mediaId = x(v(t, 0));
        if (url) {
          return { url: getHighResImageUrl(url), mediaId };
        }
      }
    } catch {}
    return null;
  }

  /**
   * Parse Google's batchexecute response chunks (wrb.fr)
   */
  function parseBatchExecuteResponse(raw) {
    let e = raw;
    if (e.startsWith(")]}'")) e = e.slice(4);

    const chunks = [];
    let r = 0;
    const n = e.length;
    while (r < n) {
      const o = e.indexOf("[", r);
      if (o < 0) break;
      let c = 0, s = false, l = false, d = -1;
      for (let u = o; u < n; u++) {
        const m = e[u];
        if (s) {
          if (l) l = false;
          else if (m === "\\") l = true;
          else if (m === '"') s = false;
          continue;
        }
        if (m === '"') s = true;
        else if (m === "[") c++;
        else if (m === "]") {
          c--;
          if (c === 0) { d = u; break; }
        }
      }
      if (d < 0) break;
      try {
        chunks.push(JSON.parse(e.slice(o, d + 1)));
      } catch {}
      r = d + 1;
    }

    for (const o of chunks) {
      if (Array.isArray(o)) {
        for (const c of o) {
          if (Array.isArray(c) && c.length && c[0] === "wrb.fr") {
            const payload = c.length > 2 ? c[2] : null;
            if (payload) {
              try {
                const data = JSON.parse(payload);
                const res = parseImageResult(data);
                if (res && res.url) return res;
              } catch {}
            }
          }
        }
      }
    }

    // Direct URL regex fallback (catches any signed flow-content or googleusercontent image URL in the raw text)
    const unescaped = raw
      .replace(/\\+u003d/gi, "=")
      .replace(/\\+u0026/gi, "&")
      .replace(/\\+"/g, '"');

    const urlMatch = unescaped.match(/https:\/\/(?:[a-zA-Z0-9-]+\.googleusercontent\.com|(?:[a-zA-Z0-9-]+\.)?flow-content\.google\/image)\/[^\s"'\\\]\)]+/);
    if (urlMatch) {
      return { url: getHighResImageUrl(urlMatch[0]) };
    }

    return null;
  }

  /**
   * Headless Image Generation via Google Flow's Authentic BatchExecute RPC (rpcid: ogiZ0b)
   */
  async function generateImageViaBatchExecute(prompt, options = {}) {
    const {
      aspectRatio = "16:9",
      model = "BELUGA",
      thinkingLevel = 4
    } = options;

    const projectId = getProjectId();
    if (!projectId) {
      throw new Error("لم يتم العثور على معرّف المشروع في الرابط! تأكد من فتح مشروعك في Google Flow (الرابط يحتوي على /project/...)");
    }

    const authIndex = getAuthIndex();
    log(`🔑 استخراج بيانات الجلسة (Auth Tokens)...`);

    // 1. Fetch Session Tokens
    const auth = await callMainWorld("flowauth");
    if (!auth || !auth.at) {
      throw new Error("تعذر قراءة رمز الأمان (at token)! تأكد من تسجيل دخولك وتحديث صفحة Google Flow.");
    }

    // 2. Mint authentic reCAPTCHA Token
    log(`🛡️ تجهيز توكن reCAPTCHA الأصلي...`);
    const captchaRes = await callMainWorld("grecaptcha", { action: "IMAGE_GENERATION" });
    const recaptchaToken = captchaRes?.token || "";
    if (!recaptchaToken) {
      log("⚠️ تحذير: لم يتم استلام رمز reCAPTCHA، جاري المتابعة برمز احتياطي...");
    }

    // 3. Map Aspect Ratio Enum (Google Flow Authentic Protobuf Schema)
    // 3 = 16:9 Landscape (Horizontal)
    // 2 = 9:16 Portrait (Vertical)
    // 1 = 1:1 Square
    // 4 = 4:3 Landscape
    // 5 = 3:4 Portrait
    let aspectEnum = 3; // Default: 16:9 Landscape
    const r = String(aspectRatio || "").trim().toLowerCase();
    if (r === "16:9" || r.includes("16:9") || r.includes("landscape") || r === "wide") {
      aspectEnum = 3;
    } else if (r === "9:16" || r.includes("9:16") || r.includes("portrait") || r === "tall") {
      aspectEnum = 2;
    } else if (r === "1:1" || r.includes("1:1") || r.includes("square")) {
      aspectEnum = 1;
    } else if (r === "4:3" || r.includes("4:3")) {
      aspectEnum = 4;
    } else if (r === "3:4" || r.includes("3:4")) {
      aspectEnum = 5;
    }

    const aspectName = {
      3: "16:9 (عريض يوتيوب)",
      2: "9:16 (طولي ريلز)",
      1: "1:1 (مربع)",
      4: "4:3 (كلاسيكي عريض)",
      5: "3:4 (كلاسيكي طولي)"
    }[aspectEnum] || `${aspectRatio}`;

    log(`📐 ضبط مقاس الصورة: ${aspectName} (Enum: ${aspectEnum})`);

    // 4. Build Payload matching Google Flow's exact schema
    const seed = Math.floor(1e5 + Math.random() * (2**31 - 1e5));
    const uuid1 = crypto.randomUUID().toUpperCase();
    const uuid2 = crypto.randomUUID().toUpperCase();
    const batchUuid = crypto.randomUUID().toUpperCase();

    const authTuple = [
      null, 22, null, null, null,
      projectId,
      null, null, null, null,
      [recaptchaToken, 1]
    ];

    const innerPayload = [
      null,
      [
        [
          null, null, null,
          seed,
          aspectEnum,
          model,
          null,
          authTuple,
          [[[ prompt ]]],
          null, null, null,
          uuid1,
          uuid2,
          thinkingLevel
        ]
      ],
      1,
      authTuple,
      [batchUuid]
    ];

    const reqId = String(Math.floor(1e5 + Math.random() * 9e5));
    const queryParams = new URLSearchParams({
      rpcids: "ogiZ0b",
      "source-path": `/u/${authIndex}/`,
      bl: auth.bl || "boq_labs-ai-sandbox-frontend_20261111.08_p0",
      "f.sid": auth.sid || "",
      hl: "en",
      _reqid: reqId,
      rt: "c"
    });

    const apiUrl = `https://flow.google.com/u/${authIndex}/_/AiSandboxAngularFrontend/data/batchexecute?${queryParams.toString()}`;

    const bodyParams = new URLSearchParams({
      "f.req": JSON.stringify([[["ogiZ0b", JSON.stringify(innerPayload), null, "generic"]]]),
      at: auth.at
    }).toString();

    log(`🚀 إرسال طلب التوليد المباشر إلى خوادم Google (BatchExecute)...`);
    const startTime = Date.now();

    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "content-type": "application/x-www-form-urlencoded;charset=UTF-8",
        "x-same-domain": "1",
        "accept": "*/*"
      },
      credentials: "include",
      body: bodyParams
    });

    if (!response.ok) {
      throw new Error(`خطأ من خادم Google: HTTP ${response.status}`);
    }

    const responseText = await response.text();
    const elapsed = Math.round((Date.now() - startTime) / 1000);

    if (responseText.includes("RESOURCE_EXHAUSTED")) {
      throw new Error("نفد رصيد توليد الصور في حساب Google أو تجاوزت حد الطلبات السريعة!");
    }

    const parsedResult = parseBatchExecuteResponse(responseText);
    if (!parsedResult || !parsedResult.url) {
      console.warn("[SigmaAutoFlow] BatchExecute raw response:", responseText.slice(0, 1000));
      throw new Error(`فشل استخراج رابط الصورة من استجابة Google! قد تكون الحصة مستنفذة أو البرومبت محظور.`);
    }

    log(`🎉 تم استلام رابط الصورة بنجاح من Google خلال ${elapsed} ثانية!`);
    return parsedResult;
  }

  /**
   * Complete Routine: API Generation -> Watermark Peeling -> Ready for Download
   */
  async function generateImageRoutine(payload) {
    const {
      sceneNumber,
      imagePrompt,
      aspectRatio = "16:9",
      removeWatermark = true
    } = payload;

    log(`[المشهد ${sceneNumber}] 🚀 بدء إجراءات توليد الصورة عبر المحرك المباشر...`);

    // 1. Generate Image via Headless BatchExecute API
    const rawResult = await generateImageViaBatchExecute(imagePrompt, {
      aspectRatio,
      model: "BELUGA"
    });

    const rawImageUrl = typeof rawResult === "string" ? rawResult : rawResult?.url;
    const mediaId = rawResult?.mediaId || null;

    let finalImageUrl = getHighResImageUrl(rawImageUrl);
    let watermarkRemoved = false;

    // 2. Watermark Peeler (Executed on full master resolution canvas)
    if (removeWatermark && typeof peelWatermark === "function") {
      try {
        log(`[المشهد ${sceneNumber}] ⚡ جاري إزالة العلامة المائية محلياً بأعلى دقة أصلية (Master 4K/HD)...`);
        const peeledUrl = await peelWatermark(finalImageUrl);
        if (peeledUrl && peeledUrl !== finalImageUrl) {
          finalImageUrl = peeledUrl;
          watermarkRemoved = true;
          log(`[المشهد ${sceneNumber}] ✨ تم إزالة العلامة المائية بنجاح مع الحفاظ على الدقة الأصلية!`);
        }
      } catch (peelErr) {
        console.warn("[SigmaAutoFlow] Peeler warning:", peelErr);
      }
    }

    return {
      success: true,
      imageResult: finalImageUrl,
      mediaId,
      watermarkRemoved: !!watermarkRemoved
    };
  }

  // Runtime Message Dispatcher
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "PING") {
      sendResponse({ status: "ok", url: location.href, hasProject: !!getProjectId(), version: "3.5.1" });
      return true;
    }

    if (message.type === "TEST_CONNECTION") {
      const pid = getProjectId();
      if (pid) {
        callMainWorld("flowauth")
          .then((auth) => {
            if (auth && auth.at) {
              sendResponse({
                success: true,
                message: `✅ متصل بنجاح بالمشروع (${pid.slice(0, 8)}...) ومحرك BatchExecute جاهز للتوليد الفوري!`
              });
            } else {
              sendResponse({
                success: false,
                message: `⚠️ تم اكتشاف المشروع، لكن يرجى تحديث صفحة Google Flow (F5) لتحميل مفاتيح الأمان.`
              });
            }
          })
          .catch((e) => {
            sendResponse({
              success: false,
              message: `خطأ في الاتصال: ${e.message}. أعد تحميل الصفحة (F5).`
            });
          });
      } else {
        sendResponse({
          success: false,
          message: "❌ يرجى فتح مشروع في Google Flow أولاً (الرابط يجب أن يحتوي على /project/...)!"
        });
      }
      return true;
    }

    if (message.type === "GENERATE_IMAGE" || message.type === "GENERATE_IMAGE_STEP") {
      generateImageRoutine(message.payload)
        .then((res) => {
          sendResponse({
            success: true,
            imageResult: res.imageResult,
            mediaId: res.mediaId,
            watermarkRemoved: !!res.watermarkRemoved
          });
        })
        .catch((err) => {
          const errMsg = String(err?.message || err || "فشل توليد الصورة");
          log(`❌ خطأ: ${errMsg}`);
          sendResponse({ success: false, error: errMsg });
        });
      return true;
    }
  });
})();
