/**
 * Sigma Auto Flow - Background Service Worker
 * 100% Free & Local Manifest V3
 */

// Configure side panel behavior
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((err) => console.warn("SidePanel setup warning:", err));

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "DOWNLOAD_MEDIA") {
    handleDownload(message.payload, sendResponse);
    return true; // async
  }

  if (message.type === "SHOW_DOWNLOAD") {
    if (message.downloadId) {
      chrome.downloads.show(message.downloadId);
      sendResponse({ success: true });
    } else {
      sendResponse({ success: false, error: "No download ID provided" });
    }
    return true;
  }

  if (message.type === "ENSURE_CONTENT_SCRIPT") {
    ensureContentScript(message.tabId)
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true; // async
  }

  if (message.type === "GET_FLOW_TAB") {
    findTargetTab()
      .then((tab) => sendResponse({ tab }))
      .catch((err) => sendResponse({ tab: null, error: err.message }));
    return true; // async
  }
});

// Monitor download status changes
chrome.downloads.onChanged.addListener((delta) => {
  if (delta.state && delta.state.current === "interrupted") {
    console.error(`[SigmaAutoFlow] Download ${delta.id} interrupted. Error:`, delta.error?.current);
  } else if (delta.state && delta.state.current === "complete") {
    console.log(`[SigmaAutoFlow] Download ${delta.id} completed successfully.`);
  }
});

/**
 * Downloads image or video file into organized LocalAutoFlow subfolder
 */
async function handleDownload(payload, sendResponse) {
  try {
    const { url, filename } = payload;
    if (!url) {
      sendResponse({ success: false, error: "No URL provided" });
      return;
    }

    // Clean filename for Windows file system safety
    const cleanName = (filename || "sigma_media")
      .replace(/[\\/:*?"<>|]/g, "_")
      .replace(/\s+/g, "_");

    const fullPath = `LocalAutoFlow/${cleanName}`;

    const downloadId = await chrome.downloads.download({
      url: url,
      filename: fullPath,
      saveAs: false,
      conflictAction: "uniquify"
    });

    sendResponse({ success: true, downloadId, path: fullPath });
  } catch (error) {
    console.error("[SigmaAutoFlow] Download error:", error);
    sendResponse({ success: false, error: String(error?.message || error) });
  }
}

/**
 * Ensure content script is running in target tab
 */
async function ensureContentScript(tabId) {
  try {
    const CURRENT_VERSION = "3.5.1";
    // Ping to check if already running and matches current version
    const pong = await chrome.tabs.sendMessage(tabId, { type: "PING" }).catch(() => null);
    if (pong && pong.status === "ok") {
      if (pong.version === CURRENT_VERSION) {
        return { success: true, injected: false, version: CURRENT_VERSION };
      }
      // Outdated version running in tab memory: reload tab to load fresh code
      console.log(`[SigmaAutoFlow] Tab ${tabId} running outdated version (${pong.version || 'unknown'}). Reloading...`);
      await chrome.tabs.reload(tabId);
      await new Promise(r => setTimeout(r, 2500));
      return { success: true, reloaded: true, version: CURRENT_VERSION };
    }

    // Inject into MAIN world first so WIZ_global_data and fetch sniffer are ready
    await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      files: ["mainworld-bridge.js"]
    }).catch((err) => console.warn("[SigmaAutoFlow] MAIN world bridge script warning:", err));

    // Inject peeler and content script into isolated world
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["peeler.js", "content.js"]
    });

    return { success: true, injected: true, version: CURRENT_VERSION };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

/**
 * Find active tab or any open tab matching Google Flow / Labs
 */
async function findTargetTab() {
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (activeTab && isTargetUrl(activeTab.url)) {
    return activeTab;
  }

  // Look for any open tab on flow.google.com or labs.google
  const allTabs = await chrome.tabs.query({});
  const flowTab = allTabs.find((t) => t.url && t.url.includes("flow.google.com"));
  if (flowTab) return flowTab;

  const labsTab = allTabs.find((t) => t.url && t.url.includes("labs.google"));
  if (labsTab) return labsTab;

  return activeTab || null;
}

function isTargetUrl(url) {
  if (!url) return false;
  return (
    url.includes("flow.google.com") ||
    url.includes("labs.google")
  );
}
