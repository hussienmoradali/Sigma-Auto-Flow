/**
 * Sigma Auto Flow - In-Browser Watermark Peeler Engine
 * Restores original pixel values under the Gemini/Flow watermark logo.
 * 100% Local Canvas & Float64 Matrix Arithmetic - Zero External Dependencies.
 */

(() => {
  if (typeof window !== "undefined" && window.__SIGMA_PEELER_INJECTED__) return;
  if (typeof window !== "undefined") window.__SIGMA_PEELER_INJECTED__ = true;

const Tr = 255, Pr = 0.002, mt = 0.99, te = 48, pt = 0.62, Cr = 0.0188, Sr = 59, Nr = 96, Lr = 8, xe = 0.5, Or = 0.32, Dr = 0.33, kr = 0.05, jr = 60, Fr = 40, _e = 12, Gr = 8, Vr = 0.02, Kr = 0.15;

const Br = "iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAIAAADYYG7QAAAGVElEQVR4nMVYvXIbNxD+FvKMWInXmd2dK7MTO7sj9QKWS7qy/Ab2o/gNmCp0JyZ9dHaldJcqTHfnSSF1R7kwlYmwKRYA93BHmkrseMcjgzgA++HbH2BBxhhmBiB/RYgo+hkGSFv/ZOY3b94w89u3b6HEL8JEYCYATCAi2JYiQ8xMDADGWsvMbfVagm6ZLxKGPXr0qN/vJ0mSpqn0RzuU//Wu9MoyPqxmtqmXJYwxxpiAQzBF4x8/fiyN4XDYoZLA5LfEhtg0+glMIGZY6wABMMbs4CaiR8brkYIDwGg00uuEMUTQ1MYqPBRRYZjZ+q42nxEsaYiV5VOapkmSSLvX62VZprUyM0DiQACIGLCAESIAEINAAAEOcQdD4a+2FJqmhDd/YEVkMpmEtrU2igCocNHW13swRBQYcl0enxbHpzEhKo0xSZJEgLIsC4Q5HJaJ2Qg7kKBjwMJyCDciBBcw7fjSO4tQapdi5vF43IZ+cnISdh9Y0At2RoZWFNtLsxr8N6CUTgCaHq3g+Pg4TVO1FACSaDLmgMhYC8sEQzCu3/mQjNEMSTvoDs4b+nXny5cvo4lBJpNJmKj9z81VrtNhikCgTsRRfAklmurxeKx9JZIsy548eeITKJgAQwzXJlhDTAwDgrXkxxCD2GfqgEPa4rnBOlApFUC/39fR1CmTyWQwGAQrR8TonMRNjjYpTmPSmUnC8ODgQHqSJDk7O9uNBkCv15tOp4eHh8SQgBICiCGu49YnSUJOiLGJcG2ydmdwnRcvXuwwlpYkSabTaZS1vyimc7R2Se16z58/f/jw4Z5LA8iy7NmzZ8J76CQ25F2UGsEAJjxo5194q0fn9unp6fHx8f5oRCQ1nJ+fbxtA3HAjAmCMCaGuAQWgh4eH0+k0y7LGvPiU3CVXV1fz+by+WQkCJYaImKzL6SEN6uMpjBVMg8FgOp3GfnNPQADqup79MLv59AlWn75E/vAlf20ibmWg0Pn06dPJZNLr9e6nfLu8//Ahv/gFAEdcWEsgZnYpR3uM9KRpOplMGmb6SlLX9Ww2q29WyjH8+SI+pD0GQJIkJycn/8J/I4mWjaQoijzPb25uJJsjmAwqprIsG4/HbVZ2L/1fpCiKoijKqgTRBlCWZcPhcDQafUVfuZfUdb1cLpfL5cePf9Lr16/3zLz/g9T1quNy+F2FiYjSNB0Oh8Ph8HtRtV6vi6JYLpdVVbmb8t3dnSAbjUbRNfmbSlmWeZ6XHytEUQafEo0xR0dHUdjvG2X3Sd/Fb0We56t6BX8l2mTq6BCVnqOjo7Ozs29hRGGlqqrOr40CIKqeiGg8Hn/xcri/rG/XeZ7/evnrjjGbC3V05YC/BSRJ8urVq36/3zX7Hjaq63o+n19fX/upUqe5VxFok7UBtQ+T6XQ6GAz2Vd6Ssizn8/nt7a3ay1ZAYbMN520XkKenpx0B2E2SLOo+FEWxWPwMgMnC3/adejZMYLLS42r7oH4LGodpsVgURdHQuIcURbFYLDYlVKg9sCk5wpWNiHym9UAEQGG6EAqSxhilRQWi0VZVmrz23yI5cPV1dX5TwsmWGYrb2TW36OJGjdXhryKxEeHvjR2Fgzz+bu6XnVgaHEmXhytEK0W1aUADJPjAL6CtPZv5rsGSvUKtv7r8/zdj+v1uoOUpsxms7qunT6+g1/TvTQCxE6XR2kBqxjyZo6K66gsAXB1fZ3neQdJSvI8X61WpNaMWCFuKNrkGuGGmMm95fhpvPkn/f6lAgAuLy/LstyGpq7r9+8d4rAr443qaln/ehHt1siv3dvt2B/RDpJms5lGE62gEy9az0XGcQCK3DL4DTPr0pPZEjPAZVlusoCSoihWqzpCHy7ODRXhbUTJly9oDr4fKDaV9NZJUrszPOjsI0a/FzfwNt4eHH+BSyICqK7rqqo0u0VRrFYridyN87L3pBYf7qvq3wqc3DMldJmiK06pgi8uLqQjAAorRG+p+zLUxks+z7rOkOzlIUy8yrAcQFVV3a4/ywBPmJsVMcTM3l/h9xDlLga4I1PDGaD7UNBPuCKBleUfy2gd+DOrPWubGHJJyD+L+LCTjEXEgH//2uSxhu1/Xzocy+VSL+2cUhrqLVZ/jTYL0IMtQEklT3/iWCutzUljDDNXVSVHRFWW7SOtccHag6V/AF1/slVRyOkZAAAAAElFTkSuQmCC";

function xr(e, t) {
  return Math.min(Nr, Math.round(Cr * Math.min(e, t) + Sr));
}

function Hr(e, t, r, n, i, a) {
  const o = new Float64Array(i * a);
  for (let c = 0; c < a; c++) {
    for (let s = 0; s < i; s++) {
      const l = ((n + c) * t + (r + s)) * 4;
      o[c * i + s] = (0.299 * e[l] + 0.587 * e[l + 1] + 0.114 * e[l + 2]) / 255;
    }
  }
  return o;
}

function ht(e, t, r, n, i, a, o) {
  const c = Math.max(0, n), s = Math.max(0, i), l = Math.min(t, n + a), d = Math.min(r, i + a);
  if (c >= l || s >= d) return 0;
  let u = 0, m = 0, p = 0, f = 0, h = 0, g = 0;
  for (let T = s; T < d; T++) {
    for (let R = c; R < l; R++) {
      const k = e[T * t + R], S = o[(T - i) * a + (R - n)];
      u += S; m += k; p += S * k; f += S * S; h += k * k; g++;
    }
  }
  const y = u / g, w = m / g, E = p / g - y * w;
  const M = Math.sqrt(Math.max(0, f / g - y * y));
  const A = Math.sqrt(Math.max(0, h / g - w * w));
  return M < 0.001 || A < 0.001 ? 0 : E / (M * A);
}

function qr(e, t, r, n, i, a, o, c) {
  let s = { conf: ht(e, t, r, n, i, a, o), x: n, y: i };
  const l = Math.max(0, i - c), d = Math.min(r - a, i + c), u = Math.max(0, n - c), m = Math.min(t - a, n + c);
  for (let p = l; p <= d; p++) {
    for (let f = u; f <= m; f++) {
      const h = ht(e, t, r, f, p, a, o);
      if (h > s.conf) s = { conf: h, x: f, y: p };
    }
  }
  return s;
}

function $r(e, t) {
  const r = (a, o) => e[Math.min(t - 1, Math.max(0, a)) * t + Math.min(t - 1, Math.max(0, o))];
  const n = new Uint8Array(t * t);
  for (let a = 0; a < t; a++) {
    for (let o = 0; o < t; o++) {
      const c = r(a - 1, o + 1) + 2 * r(a, o + 1) + r(a + 1, o + 1) - (r(a - 1, o - 1) + 2 * r(a, o - 1) + r(a + 1, o - 1));
      const s = r(a + 1, o - 1) + 2 * r(a + 1, o) + r(a + 1, o + 1) - (r(a - 1, o - 1) + 2 * r(a - 1, o) + r(a - 1, o + 1));
      if (Math.abs(c) + Math.abs(s) > Kr) n[a * t + o] = 1;
    }
  }
  const i = new Uint8Array(t * t);
  for (let a = 0; a < t; a++) {
    for (let o = 0; o < t; o++) {
      let c = 0;
      for (let s = -1; s <= 1 && !c; s++) {
        for (let l = -1; l <= 1 && !c; l++) {
          const d = a + s, u = o + l;
          if (d >= 0 && d < t && u >= 0 && u < t && n[d * t + u]) c = 1;
        }
      }
      i[a * t + o] = c;
    }
  }
  return i;
}

function St(e, t, r, n, i) {
  const a = e.slice(), o = n.slice();
  let c = 0;
  for (let d = 0; d < o.length; d++) if (o[d]) c++;
  while (c > 0) {
    const d = [], u = [];
    for (let m = 0; m < r; m++) {
      for (let p = 0; p < t; p++) {
        const f = m * t + p;
        if (!o[f]) continue;
        let h = 0, g = 0;
        if (m > 0 && !o[f - t]) { h += a[f - t]; g++; }
        if (m < r - 1 && !o[f + t]) { h += a[f + t]; g++; }
        if (p > 0 && !o[f - 1]) { h += a[f - 1]; g++; }
        if (p < t - 1 && !o[f + 1]) { h += a[f + 1]; g++; }
        if (g > 0) { d.push(f); u.push(h / g); }
      }
    }
    for (let m = 0; m < d.length; m++) {
      a[d[m]] = u[m];
      o[d[m]] = 0;
    }
    c -= d.length;
    if (d.length === 0) break;
  }
  let s = a, l = a.slice();
  for (let d = 0; d < i; d++) {
    for (let m = 1; m < r - 1; m++) {
      for (let p = 1; p < t - 1; p++) {
        const f = m * t + p;
        l[f] = n[f] ? (s[f - t] + s[f + t] + s[f - 1] + s[f + 1]) * 0.25 : s[f];
      }
    }
    const u = s; s = l; l = u;
  }
  return s;
}

function Wr(e, t, r, n, i, a, o, c) {
  const s = _e;
  if (n - s < 0 || i - s < 0 || n + a + s > t || i + a + s > r) return null;
  const l = a + 2 * s, d = [];
  for (let u = 0; u < 3; u++) {
    const m = new Float64Array(l * l);
    for (let g = 0; g < l; g++) {
      for (let y = 0; y < l; y++) {
        m[g * l + y] = e[((i - s + g) * t + (n - s + y)) * 4 + u] / 255;
      }
    }
    const p = St(m, l, l, c, jr);
    let f = 0, h = 0;
    for (let g = 0; g < a; g++) {
      for (let y = 0; y < a; y++) {
        const w = e[((i + g) * t + (n + y)) * 4 + u] / 255;
        const E = p[(g + s) * l + (y + s)];
        const M = o[g * a + y] * (1 - E);
        f += (w - E) * M; h += M * M;
      }
    }
    d.push(h > 1e-6 ? f / h : 0);
  }
  return d;
}

function Xr(e) {
  const t = Math.round(e);
  return Math.abs(e % 1) === 0.5 && t % 2 !== 0 ? t - 1 : t;
}

function Jr(e, t, r, n, i, a, o) {
  const c = Gr;
  if (n - c < 0 || i - c < 0 || n + a + c > t || i + a + c > r) return;
  const s = a + 2 * c, l = new Uint8Array(s * s);
  for (let d = 0; d < a; d++) {
    for (let u = 0; u < a; u++) l[(d + c) * s + (u + c)] = o[d * a + u];
  }
  for (let d = 0; d < 3; d++) {
    const u = new Float64Array(s * s);
    for (let p = 0; p < s; p++) {
      for (let f = 0; f < s; f++) u[p * s + f] = e[((i - c + p) * t + (n - c + f)) * 4 + d] / 255;
    }
    const m = St(u, s, s, l, Fr);
    for (let p = 0; p < a; p++) {
      for (let f = 0; f < a; f++) {
        const h = m[(p + c) * s + (f + c)] * 255;
        e[((i + p) * t + (n + f)) * 4 + d] = Xr(Math.min(255, Math.max(0, h)));
      }
    }
  }
}

function gt(e, t, r, n, i, a, o, c) {
  const s = Math.max(0, n), l = Math.max(0, i), d = Math.min(t, n + a), u = Math.min(r, i + a);
  for (let m = l; m < u; m++) {
    for (let p = s; p < d; p++) {
      let f = o[(m - i) * a + (p - n)] * c;
      if (f < Pr) continue;
      if (f > mt) f = mt;
      const h = 1 - f, g = (m * t + p) * 4;
      for (let y = 0; y < 3; y++) {
        let w = (e[g + y] - f * Tr) / h;
        w = Math.round(Math.min(255, Math.max(0, w)));
        e[g + y] = w;
      }
    }
  }
}

function Qr(e, t, r, n, i = te, a = null, o = !0) {
  const c = xr(t, r), s = t - c - i, l = r - c - i, d = Lr;
  const u = Math.max(0, s - d), m = Math.max(0, l - d);
  const p = Math.min(t, s + i + d) - u, f = Math.min(r, l + i + d) - m;
  const h = Hr(e, t, u, m, p, f);
  const g = qr(h, p, f, s - u, l - m, i, n, d);
  const y = g.conf, w = g.x + u, E = g.y + m;

  if (!o) {
    const O = y >= xe ? w : s, D = y >= xe ? E : l;
    return gt(e, t, r, O, D, i, n, a ?? pt), { removed: !0, conf: y, x: O, y: D, g: null };
  }

  const M = new Uint8Array((i + 2 * _e) * (i + 2 * _e));
  for (let O = 0; O < i; O++) {
    for (let D = 0; D < i; D++) {
      if (n[O * i + D] > Vr) M[(O + _e) * (i + 2 * _e) + (D + _e)] = 1;
    }
  }

  const A = [[s, l]];
  if (y >= xe && (w !== s || E !== l)) A.push([w, E]);
  let T = null;
  for (const [O, D] of A) {
    const W = Wr(e, t, r, O, D, i, n, M);
    if (W && (!T || Math.min(...W) > Math.min(...T.g))) T = { x: O, y: D, g: W };
  }

  if (!T) return { removed: !1, conf: y, x: s, y: l, g: null };
  const { x: R, y: k, g: S } = T;
  const G = (S[0] + S[1] + S[2]) / 3;
  if (Math.min(...S) < Or || G < Dr) return { removed: !1, conf: y, x: R, y: k, g: S };
  const H = a ?? Math.min(pt, G + kr);
  gt(e, t, r, R, k, i, n, H);
  Jr(e, t, r, R, k, i, $r(n, i));
  return { removed: !0, conf: y, x: R, y: k, g: S };
}

let He = null;

function Nt(e) {
  return new Promise((t, r) => {
    const n = new Image();
    n.crossOrigin = "anonymous";
    n.onload = () => t(n);
    n.onerror = () => r(new Error("image load failed"));
    n.src = e;
  });
}

async function Yr() {
  if (He) return He;
  const e = await Nt(`data:image/png;base64,${Br}`);
  const t = document.createElement("canvas");
  t.width = te; t.height = te;
  const r = t.getContext("2d");
  if (!r) throw new Error("no 2d context");
  r.drawImage(e, 0, 0, te, te);
  const n = r.getImageData(0, 0, te, te).data;
  const i = new Float64Array(te * te);
  for (let a = 0; a < i.length; a++) i[a] = Math.max(n[a * 4], n[a * 4 + 1], n[a * 4 + 2]) / 255;
  return He = i, i;
}

/**
 * Main Exported Watermark Peeler
 * Strips the Flow/Gemini logo in the corner and returns clean image as Data URL
 */
async function peelWatermark(imgSrc) {
  try {
    const [img, mask] = await Promise.all([Nt(imgSrc), Yr()]);
    const width = img.naturalWidth || img.width;
    const height = img.naturalHeight || img.height;
    if (!width || !height) return imgSrc;

    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return imgSrc;

    ctx.drawImage(img, 0, 0);
    const imgData = ctx.getImageData(0, 0, width, height);
    const res = Qr(imgData.data, width, height, mask);

    if (res.removed) {
      ctx.putImageData(imgData, 0, 0);
      return canvas.toDataURL("image/png", 1.0);
    }
    return imgSrc;
  } catch (err) {
    console.warn("[SigmaAutoFlow] Watermark peel skipped:", err);
    return imgSrc;
  }
}

// Export for ES modules or global window
if (typeof window !== "undefined") {
  window.peelWatermark = peelWatermark;
}
if (typeof module !== "undefined" && module.exports) {
  module.exports = { peelWatermark };
}
})();
